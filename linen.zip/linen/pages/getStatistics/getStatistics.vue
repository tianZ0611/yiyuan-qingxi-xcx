<template>
	<view class="box fs16">
		<view class="fs16 bcbai padl20 padt10 padb10 marb8 posr" v-for="i in list" :key="i.id">
			<view class="">名称：{{i.ming}}</view>
			<view class="mart10">部门：{{i.bumen}}</view>
			<view class="mart10">规格：{{i.guige}}</view>
			<view class="mart10">状态：{{i.ling}}</view>
			<view class="posab10r40">
				<view class="fs36 colorlan">
					{{i.shuliang}}
				</view>
				<view class="mart10 textjz">
					数量
				</view>
			</view>
		</view>

		<view class="posfb80 disf">
			<button class="w145h44 marl30 bclan colorbai">上一步</button>
			<button class="w145h44 marl30 bclan colorbai" @click="lingyong()">确认领用</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					id: 1,
					ming: "整套",
					bumen: "神经内科9A-909",
					guige: "普通面料",
					ling: "领用",
					shuliang: '1270'
				}, {
					id: 2,
					ming: "整套",
					bumen: "神经内科9A-909",
					guige: "普通面料",
					ling: "领用",
					shuliang: '170'
				}]
			}
		},
		methods: {
			lingyong() {

				uni.showModal({
					title: '提示',
					content: '请确认数量无误后点击确定完成领用操作',
					success: function(res) {
						if (res.confirm) { //这里是点击了确定以后
							console.log('用户点击确定')
						} else { //这里是点击了取消以后
							console.log('用户点击取消')
						}
					}
				})
			}
		}
	}
</script>

<style>

</style>