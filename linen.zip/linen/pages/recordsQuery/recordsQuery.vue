<template>
	<view class="box fs16">
		<view class="bcbai">
			<view class="fs12 colorhui padl20">领用记录查询</view>
			<!-- <uni-section :title="'日期用法：' + single" type="line"></uni-section> -->
			<view class="borb1lan marl10 marr10 borr3 mart20 marb20">
				<uni-datetime-picker type="date" :clear-icon="false" v-model="single" @maskClick="maskClick" />
			</view>
			<view class="fs16 padl20 padt10 padb10 marb8 posr" v-for="i in list" :key="i.id">
				<view class="">名称：{{i.ming}}</view>
				<view class="mart10">部门：{{i.bumen}}</view>
				<view class="mart10">规格：{{i.guige}}</view>
				<view class="mart10">状态：{{i.ling}}</view>
				<view class="posab10r40">
					<view class="fs36 colorlan">
						{{i.shuliang}}
					</view>
					<view class="mart10 textjz">
						数量
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [{
					id: 1,
					ming: "整套",
					bumen: "神经内科9A-909",
					guige: "普通面料",
					ling: "领用",
					shuliang: '1270'
				}, {
					id: 2,
					ming: "整套",
					bumen: "神经内科9A-909",
					guige: "普通面料",
					ling: "领用",
					shuliang: '170'
				}]
			}
		},
		methods: {
			maskClick(e) {
				console.log('maskClick事件:', e);
			}
		}
	}
</script>

<style>

</style>