<template>
	<view>
		<uni-table class="w690" border stripe emptyText="暂无更多数据">
			<!-- 表头行 -->
			<uni-tr class="w690 fs14">
				<uni-th width="90" align="center">ID</uni-th>
				<uni-th width="90" align="center">名称</uni-th>
				<uni-th width="90" align="left">部门</uni-th>
				<uni-th width="90" align="left">次数</uni-th>
			</uni-tr>
			<!-- 表格数据行 -->
			<uni-tr class="fs14">
				<uni-td>8871828172</uni-td>
				<uni-td>Jeson</uni-td>
				<uni-td>北京市海淀区</uni-td>
				<uni-td>29</uni-td>
			</uni-tr>

		</uni-table>
		<view class="posfb80 disf">
			<button class="w145h44 marl30 bclan colorbai" @click="gogetstatistics()">下一步</button>
			<button class="w145h44 marl30 bclan colorbai">开始扫描</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			gogetstatistics() {
				uni.navigateTo({
					url: "/pages/getStatistics/getStatistics"
				})
			}
		}
	}
</script>

<style>

</style>