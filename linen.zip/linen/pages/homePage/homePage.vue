<template>
	<view class="box">
		<view class="w690 bcbai borr8 padt20 padl20 padb20 posr">
			<view class="disf">
				<img class="wh56" src="@/static/gongzuotai/name.png" alt="" />
				<view class="fs18 marl12">{{list.name}}</view>
			</view>
			<view class="disf mart20">
				<img class="wh56" src="@/static/gongzuotai/name.png" alt="" />
				<view class="fs18 marl12">{{list.tit}}</view>
			</view>
			<view class="disf posat20r20">
				<img class="wh56" src="@/static/gongzuotai/name.png" alt="" />
				<view class="fs18 marl12">{{list.time}}</view>
			</view>
			<button class="fs14 w160h60 posab20r20">交接班</button>
		</view>



		<view class="w690 bcbai borr8 padt10 padl20 padb20 posr mart10">
			<view class="disf">
				<view class="wh60 bchuang borr3">
					<img class="wh40 mart5 marl5" src="@/static/gongzuotai/sao.png" alt="" />

				</view>
				<view class="fs16 marl12 h30">扫一扫快速盘点</view>
			</view>
			<view class="mart6 fw">
				<span class="colorlan">一 键 扫 描</span>
				<span class="marl8 colorhuang">简 单 读 取</span>
			</view>
			<view class="mart6 fw colorlan">
				快 捷 实 现 出 入 盘 对
			</view>
			<view class="posab0r20 posr">
				<img class="wh94" src="@/static/gongzuotai/shaomiao1.png" alt="" />
				<img class="wh35 posab20r0" src="@/static/gongzuotai/saomiao.png" alt="" />
			</view>
		</view>


		<view class="w730 bcbai borr8 padt10 padb20 posr mart10">
			<view class="fs12 colorhui padl20">日常管理</view>
			<view class=" mart40 disf jussa">
				<view class="w45" v-for="i in list11" :key="i.id" @click="receive(i.id)">
					<view class="bchuang wh90 borr8">
						<img class="wh56 mart5 marl8 mart8" :src="i.img" alt="" />
					</view>
					<view class="textjz mart8 fs14">
						{{i.name}}
					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: {
					name: '张三',
					tit: '物资管理部',
					time: '2024/09/20 15:29'
				},
				list11: [{
					id: 1,
					name: "领用",
					img: "../../static/gongzuotai/lingyong.png"
				}, {
					id: 2,
					name: "收污",
					img: "../../static/gongzuotai/shouwu.png"
				}, {
					id: 3,
					name: "清洗",
					img: "../../static/gongzuotai/qingxi.png"
				}, {
					id: 4,
					name: "库存",
					img: "../../static/gongzuotai/kucun.png"
				}, {
					id: 5,
					name: "送净",
					img: "../../static/gongzuotai/shouwu.png"
				}]
			}
		},
		methods: {
			receive(id) {
				if (id == 1) { //领用
					uni.navigateTo({
						url: "/pages/receive/receive"
					})
				}
			}
		}
	}
</script>

<style>

</style>